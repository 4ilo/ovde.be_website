/*
 * relais_moduleV1.c
 *
 * Created: 24/04/2015 8:21:09
 *  Author: Administrator
 */ 


#include <avr/io.h>
#define F_CPU 1000000
#include <util/delay.h>
#include <avr/interrupt.h>

#include "nRF24L01.h"

uint8_t * recData = 0;			//variabele om nrf data te ontvangen

void verander_adres(void);

int main(void)
{
	InitSPI();
	nrf24l01_init_RX();
	verander_adres();		//het adres veranderen
	INT0_interupt_init();
	sei();
	
	DDRD |= (1<<PD1);		//als output schakelen, om de led aan te sturen
	SETBIT(PORTD,1);
	_delay_ms(1000);
	CLEARBIT(PORTD,1);
	_delay_ms(1000);
	
    while(1)
    {
        nrf_reset();				//nrf ontvangstregister leegmaken
        recieve_Data();				//kijken of er data is
		
		if (recData[0] != 0)
		{
			if (recData[0] == 0x20)		//dan is de data voor hier
			{
				if (recData[1] == 0x30)		//als 0x30 dan moet de verwarming aan
				{
					SETBIT(PORTD,1);
				} 
				else
				{
					CLEARBIT(PORTD,1);
				}
			} 
		} 
    }
}

ISR(INT0_vect)		//interuptroutine als er data ontvangen is
{
	nrf_int_disable();				//interupts uitzetten, want de data is ontvangen
	CLEARBIT(PORTB,1);		//ce laag maken -> stop met luisteren naar data
	
	recData = WriteToNrf(R,R_RX_PAYLOAD, recData ,datlen);	//data binnenhalen uit recieve register
}

void verander_adres(void)		//deze functie veranderd het adres van de transciever om meerdere comunicaties te doen
{
	uint8_t setup[5];
	
	//RX RF_adress setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x14;	//0x12 x 5 is het adres, het moet hetzelfde zijn op de reciever-transmitter
	}
	WriteToNrf(W,RX_ADDR_P0, setup, 5);	//we hebben datapipe0 gekozen, dus geven we deze een adres
	
	//TX RF_adr setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x14;		//adres hetzelfde op reciever en transmitter
	}
	WriteToNrf(W, TX_ADDR, setup, 5);
}