/*
 * knoppen.h
 *
 * Created: 28/03/2015 14:40:45
 *  Author: Olivier
 */ 

/*
knop layout:		knop 1			knop 3

					knop 2			knop 4

*/

uint8_t knoppen[3];			//een array om de knoppen in te lezen


void lees_knoppen(void)			//leest de knoppen uit, en zet de waarde in de globale array "knoppen[3"
{
	uint8_t getal;
	
	i2c_start();
	i2c_send(0b01110001);		//expander aanspreken
	getal = i2c_receive(1);		//byte lezen
	
	getal = getal << 4;			//nibble switchen
	
	for (uint8_t i=0; i<4; i++)
	{
		uint8_t kopie = getal;
		kopie = kopie <<i;		//i keer doorschuiven afhankelijk van de knop
		kopie = kopie & 0b10000000;		//enkel hoogste bit overhouden
		
		if (kopie == 0b10000000)
		{
			switch(i)
			{
				case 0: knoppen[0] = 0; break;
				case 1: knoppen[3] = 0; break;			//juiste knop op de juiste plaats in de array
				case 2: knoppen[1] = 0; break;
				case 3: knoppen[2] = 0; break;
			}
		}
		else
		{
			switch(i)
			{
				case 0: knoppen[0] = 1; break;
				case 1: knoppen[3] = 1; break;			//juiste knop op de juiste plaats in de array
				case 2: knoppen[1] = 1; break;
				case 3: knoppen[2] = 1; break;
			}
		}
		
	}
}

