/*
 * rotary.h
 *
 * Created: 27/03/2015 11:01:30
 *  Author: Olivier
 */ 



#define ROTPORT PORTC
#define ROTDDR DDRC			//de poort waar de rotary encoder op aagesloten is
#define ROTPIN PINC

#define ROTPA PC0
#define ROTPB PC1				//rotary encoder pinnen
#define ROTPBUTTON    PC2

#define ROTA !((1<<ROTPA)&ROTPIN)
#define ROTB !((1<<ROTPB)&ROTPIN)		//macro's
#define ROTCLICK !((1<<ROTPBUTTON)&ROTPIN)

void RotaryInit(void);
void RotaryCheckStatus(void);		//functies
uint8_t RotaryGetStatus(void);
void RotaryResetStatus(void);

uint8_t rotarystatus;			//variabele om stand van rotary uit te lezen

void RotaryInit(void)
{
	//pinnen als input zetten
	ROTDDR &= ~((1<<ROTPA)|(1<<ROTPB)|(1<<ROTPBUTTON));
}

void RotaryCheckStatus(void)
{
	//Lezen van rotary encoder en knop
	//Kijken of er links gedraaid word
	if(ROTA & (!ROTB)){
		while (bit_is_clear(ROTPIN, ROTPA)); 
		if (ROTB) rotarystatus=1;	//als links draaiend, op 1 zetten
		
		//check if rotation is right
		}else if(ROTB & (!ROTA)){
		while(bit_is_clear(ROTPIN, ROTPB));
		if (ROTA)
		rotarystatus=2;		//als rechts draaiend, op 2 zetten
		}else if (ROTA & ROTB){
		while (bit_is_clear(ROTPIN, ROTPA)); 
		if (ROTB)
		rotarystatus=1;		//als links, op 1 zetten
		else rotarystatus=2;	//als recht op 2
	}

}


uint8_t RotaryGetStatus(void)
{
	return rotarystatus;		//status van de encoder opvragen
}

void RotaryResetStatus(void)
{
	rotarystatus=0;				//register resetten
}

void Timer0_Start(void)
{
	TCCR0B|=(1<<CS01); //prescaller 8~122 interrupts/s
	TIMSK0|=(1<<TOIE0);//Enable Timer0 Overflow interrupts
	sei();
}