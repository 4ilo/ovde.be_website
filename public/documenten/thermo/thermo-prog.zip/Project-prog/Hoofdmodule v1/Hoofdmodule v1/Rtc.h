/*
 * Rtc.h
 *
 * Created: 27/03/2015 10:44:54
 *  Author: Olivier
 */ 

/*	Hier staan de functies beschreven voor de i2c en rtc

	void init_RTC(void)
	void RTC_write(uint8_t reg, uint8_t data)
	uint8_t RTC_Read(uint8_t reg)

	void BCD_To_ASCII(unsigned char bcd_value, char * p_ascii_text)
	
*/

void init_RTC(void);
void RTC_write(uint8_t reg, uint8_t data);
uint8_t RTC_Read(uint8_t reg);
void get_uur(void);
uint8_t BCDToDecimal (uint8_t);

void BCD_To_ASCII(unsigned char bcd_value, char * p_ascii_text);

char uurRtc[2];
char minRtc[2];
uint8_t uurtc,mintc;


//hier de functies voor het rtc te besturen

void init_RTC(void)
{
	RTC_write(0b00000000,0x00);		//secondenregister op 0
	RTC_write(0x00000001,0x00);		//minutenregister op 0
	RTC_write(0x00000010,0x00);		//urenregister op 0
}

void RTC_write(uint8_t reg, uint8_t data)
{

	i2c_start();			//startconditie sturen
	i2c_send(0b11010000); 	// rtc aanspreken in write mode

	i2c_send(reg);			//het juiste register aanspreken
	i2c_send(data);			//de data sturen
	
	i2c_stop();				//stopconditie sturen

}

uint8_t RTC_Read(uint8_t reg)
{
	uint8_t data;			//variabele om data te ontvangen
	
	i2c_start();			//startconditie sturen
	i2c_send(0b11010000);	//rtc aanspreken in write mode
	i2c_send(reg);			//het juiste register aanspreken
	
	i2c_stop();
	i2c_start();			//nieuwe startconditie
	i2c_send(0b11010001); 	//opniuew aanspreken rtc maar nu in read mode

	data = i2c_receive(0);	//register uitlezen en data opslaan
	
	i2c_stop();				//stopconditie sturen
	
	return data;			//data returnen
	
}

void get_uur(void)
{
	uint8_t uren = 0;
	uint8_t minuten = 0;
	
	minuten = RTC_Read(0x01);		//minuten lezen
	uren = RTC_Read(0x02);			//uren uitlezen
	
	BCD_To_ASCII(uren,uurRtc);
	BCD_To_ASCII(minuten,minRtc);		//omzetten naar string voor lcd
	
	uurtc = BCDToDecimal(uren);		//ook omzetten naar int voor de berekeningen
	mintc = BCDToDecimal(minuten);
}

//deze functie zet een bcd getal om naar een string

void BCD_To_ASCII(unsigned char bcd_value, char * p_ascii_text)
{
	//--------------------------------------------------
	// BCD contains digits 0 .. 9 in the binary nibbles
	//--------------------------------------------------
	*p_ascii_text++ = (bcd_value >> 4)  + '0';
	*p_ascii_text++ = (bcd_value & 0x0f) + '0';
	*p_ascii_text = '\0';
	return;
}

 
 uint8_t BCDToDecimal (uint8_t bcdByte)
 {
	 return (((bcdByte & 0xF0) >> 4) * 10) + (bcdByte & 0x0F);
 }
