/*
 * i2c.h
 *
 * Created: 27/03/2015 8:26:45
 *  Author: Olivier
 */ 

void i2c_start(void)
{
	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);		//startconditie maken
	
	while((TWCR & (1<<TWINT)) == 0);	//wachten tot transmittie voltooid is
}

void i2c_stop(void)
{
	TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);		//stuur stopconditie
}

void i2c_send(uint8_t DataByte)
{
	TWDR = DataByte;		//byte in i2c register laden
	TWCR = (1<<TWINT) | (1<<TWEN);		//interupt wegdoen en transmittie starten
	
	while((TWCR & (1<<TWINT)) == 0);	//wachten tot transmittie voltooid is
}

uint8_t i2c_receive(uint8_t ack)
{
	if (ack == 1)
	{
		TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN); //interupt clearen en transmittie starten met ack
	} 
	else
	{
		TWCR = (1<<TWINT) | (1<<TWEN);		//interupt clearen en transmittie starten zonder ack
	}
	
	while((TWCR & (1<<TWINT)) == 0); //wachten tot data binnen is
	
	return TWDR;		//ontvangen byte returnen
}