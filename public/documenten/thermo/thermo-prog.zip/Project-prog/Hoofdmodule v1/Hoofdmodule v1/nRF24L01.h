

uint8_t datlen = 4;


/*  Copyright (c) 2007 Stefan Engelke <mbox@stefanengelke.de> 
    Deze defines zijn gedownload van internet om het programma makkelijker te maken
 */


/* Memory Map */

#define CONFIG      0x00

#define EN_AA       0x01

#define EN_RXADDR   0x02

#define SETUP_AW    0x03

#define SETUP_RETR  0x04

#define RF_CH       0x05

#define RF_SETUP    0x06

#define STATUS      0x07

#define OBSERVE_TX  0x08

#define CD          0x09

#define RX_ADDR_P0  0x0A

#define RX_ADDR_P1  0x0B

#define RX_ADDR_P2  0x0C

#define RX_ADDR_P3  0x0D

#define RX_ADDR_P4  0x0E

#define RX_ADDR_P5  0x0F

#define TX_ADDR     0x10

#define RX_PW_P0    0x11

#define RX_PW_P1    0x12

#define RX_PW_P2    0x13

#define RX_PW_P3    0x14

#define RX_PW_P4    0x15

#define RX_PW_P5    0x16

#define FIFO_STATUS 0x17

#define DYNPD	    0x1C

#define FEATURE	    0x1D




/* Bit Mnemonics */

#define MASK_RX_DR  6

#define MASK_TX_DS  5

#define MASK_MAX_RT 4

#define EN_CRC      3

#define CRCO        2

#define PWR_UP      1

#define PRIM_RX     0

#define ENAA_P5     5

#define ENAA_P4     4

#define ENAA_P3     3

#define ENAA_P2     2

#define ENAA_P1     1

#define ENAA_P0     0

#define ERX_P5      5

#define ERX_P4      4

#define ERX_P3      3

#define ERX_P2      2

#define ERX_P1      1

#define ERX_P0      0

#define AW          0

#define ARD         4

#define ARC         0

#define PLL_LOCK    4

#define RF_DR       3

#define RF_PWR      6

#define RX_DR       6

#define TX_DS       5

#define MAX_RT      4

#define RX_P_NO     1

#define TX_FULL     0

#define PLOS_CNT    4

#define ARC_CNT     0

#define TX_REUSE    6

#define FIFO_FULL   5

#define TX_EMPTY    4

#define RX_FULL     1

#define RX_EMPTY    0

#define DPL_P5	    5

#define DPL_P4	    4

#define DPL_P3	    3

#define DPL_P2	    2

#define DPL_P1	    1

#define DPL_P0	    0

#define EN_DPL	    2

#define EN_ACK_PAY  1

#define EN_DYN_ACK  0




/* Instruction Mnemonics */

#define R_REGISTER    0x00

#define W_REGISTER    0x20

#define REGISTER_MASK 0x1F

#define ACTIVATE      0x50

#define R_RX_PL_WID   0x60

#define R_RX_PAYLOAD  0x61

#define W_TX_PAYLOAD  0xA0

#define W_ACK_PAYLOAD 0xA8

#define FLUSH_TX      0xE1

#define FLUSH_RX      0xE2

#define REUSE_TX_PL   0xE3

#define NOP           0xFF




/* Non-P omissions */

#define LNA_HCURR   0




/* P model memory Map */

#define RPD         0x09




/* P model bit Mnemonics */

#define RF_DR_LOW   5

#define RF_DR_HIGH  3

#define RF_PWR_LOW  1

#define RF_PWR_HIGH 2

/* Vanaf hier start de eigen gemaakte code */

/* De pinout voor de nrf zit op poortB voor de spi-bus

	- CE --> PB1
	- CSN --> PB2
	- MOSI --> PB3
	- MISO --> PB4
	- SCK --> PB5
	- INT --> PD2 (INT0)
	
*/


/* Een paar defines om de code makkelijker te maken*/

#define BIT(x) (1 << (x))
#define SETBITS(x,y) ((x) |= (y))
#define CLEARBITS(x,y) ((x) &= (~(y)))
#define SETBIT(x,y) SETBITS((x), (BIT((y))))
#define CLEARBIT(x,y) CLEARBITS ((x), (BIT((y))))

#define W 1		//write is 1
#define R 0		//read is 0


// hier staan de functie declaraties

void InitSPI(void);
uint8_t WriteByteSPI(uint8_t);
uint8_t GetReg(uint8_t);
uint8_t *WriteToNrf(uint8_t, uint8_t, uint8_t*, uint8_t);
void nfr24l01_init_TX(void);
void nfr24l01_init_RX(void);
void transmit_payload(uint8_t * buff);

//de functies zelf

void InitSPI(void)
{
	//SCK,MOSI,CSN en ce als output zetten
	DDRB |= (1<<DDB5) | (1<<DDB3) | (1<<DDB2) | (1<<DDB1);
	
	//SPI aanzetten in mastermode en klok= fck/16.
	SPCR |= (1<<SPE) | (1<<MSTR);
	
	SETBIT(PORTB,2);	//CSN hoogzetten om mee te starten
	CLEARBIT(PORTB,1);	//ce laag om mee te starten
}

uint8_t WriteByteSPI(uint8_t Dbyte)
{
	//byte laden in dataregister
	SPDR = Dbyte;
	
	//wachten tot versturen voltooid is
	while (!(SPSR & (1<<SPIF)));
	
	//returen wat er terugkomt uit de spi-bus
	return SPDR;
}

uint8_t GetReg(uint8_t reg)
{
	_delay_us(20);	//zeker zijn dat vorige comunicatie gedaan is
	CLEARBIT(PORTB,2);	//csn laag zetten, nrf wacht nu op comando
	_delay_us(20);
	WriteByteSPI(R_REGISTER + reg);	//R_register = nrf in read mode zetten, "reg" = het register dat wordt teruggelezen
	_delay_us(20);
	reg = WriteByteSPI(NOP);		//dummy byte sturen om data terug binnen te lezen uit "reg" register
	_delay_us(20);
	SETBIT(PORTB,2);	//csn hterug hoog, nrf doet terug niks
	
	return reg;	//return van het gelezen register
}

uint8_t *WriteToNrf(uint8_t ReadWrite, uint8_t reg, uint8_t *pack, uint8_t aantpack)
{
	//"Readwrite" = "W" of "R", reg = register om naar te sturen, pack = array met de data, aantpack = aantal data in de array
	
	if (ReadWrite == W)		//als het w is, willen we schrijven
	{
		reg = W_REGISTER + reg;		//we voegen de write bit toe aan het register
	}
	
	//we maken een array om op het einde de data te returnen
	static uint8_t ret[32];
	
	_delay_us(10);		//er zeker van zijn dat alle comunicatie gedaan is
	CLEARBIT(PORTB,2);	//csn laag zetten, nrf luisterd nu
	_delay_us(10);
	WriteByteSPI(reg);	//nrf in lees of schrijfmode zetten voor het "reg" register
	_delay_us(10);
	
	for(uint8_t i = 0; i<aantpack; i++)
	{
		if (ReadWrite == R && reg != W_TX_PAYLOAD)	//read comando?
		{											//w_tx_payload is een uitzondering, deze kan niet het w bevatten
			ret[i] = WriteByteSPI(NOP);		//dummy bytes sturen om data binnen te halen
			_delay_us(10);
		} 
		else
		{
			WriteByteSPI(pack[i]);		//stuur de data naar de nrf 1 per 1
			_delay_us(10);
		}
	}
	
	SETBIT(PORTB,2);		//csn terug hoog, nrf doet nu niks meer
	return ret;		//de array terugsturen
	 
}


void transmit_Data(uint8_t * buff)
{
	WriteToNrf(R, FLUSH_TX, buff, 0);	//alle oude data verwijderen uit de chip met flush
	WriteToNrf(R, W_TX_PAYLOAD, buff, datlen);	//stuur de data in de buffer naar de nrf
	
	nrf_int_enable();		//interupt opstarten om te kijken of transmittie kan voltooien
	
	_delay_ms(20);		//even wachten zodat de data er zeker inzit
	SETBIT(PORTB, 1);	//ce hoogzetten = transmit data
	_delay_us(20);		//even wachten
	CLEARBIT(PORTB,1);	//ce terug naar omlaag -> transmittie stoppen
	_delay_ms(20);		//even wachten voor einde
	
}

void nrf_reset(void)		//reset alle interupt messages in de nrf
{
	_delay_us(20);
	CLEARBIT(PORTB, 2); //csn laag maken
	_delay_us(20);
	WriteByteSPI(W_REGISTER + STATUS);	//write to status reg
	_delay_us(20);
	WriteByteSPI(0x70);	//reset alle irq in status reg
	_delay_us(20);
	SETBIT(PORTB,2);	//csn terug hoog
}

void INT0_interupt_init(void)		//interupt initialiseren
{
	DDRD &= ~(1<<DDD2);			//INT0 als input zetten
		
	EICRA |= (1<<ISC01);	//int falling edge
	EICRA &= ~(1<<ISC00);	//falling edge
	
	EIMSK |= (1<<INT0);		//Int0 enable
}

void nrf_int_enable(void)
{
	EIMSK |= (1<<INT0);		//interupt aan
}

void nrf_int_disable(void)
{
	EIMSK &= ~(1<<INT0);	//interupt uitzetten
}

void recieve_Data(void)
{
	WriteToNrf(R, FLUSH_RX, NOP, 0);	//alle oude data verwijderen uit de chip met flush
	nrf_int_enable();				//interupt inschakelen om te kijken of er nieuwe data us
	
	SETBIT(PORTB,1);		//luisteren naar data
	_delay_ms(1000);		//1s luisteren
	CLEARBIT(PORTB,1);		//stop met luisteren
	
	nrf_int_disable();				//als er nu geen interupt is, is er geen data, dus int terug uit
}

void nrf24l01_init_RX(void)		//functie voor het initialiseren van de nrf in reciever mode
{
	_delay_ms(100);		//wachten om er zeker van te zijn dat alle comunicatie gedaan is
	
	uint8_t setup[5];	//een array om de writeToNrf functie te gebruiken
	
	//EN_AA = auto ack uitzetten voor alle pipes
	setup[0] = 0x00;		//de registerwaarde zetten
	WriteToNrf(W,EN_AA, setup,1);	//data sturen naar register
	
	//SETUP_RETR stelt het aantal pogingen in bij een mislukte transmittie
	setup[0] = 0x2f;		//0b0010 1111: elke 750us opnieuw proberen bij mislukking, 15keer opnieuw proberen
	WriteToNrf(W,SETUP_RETR, setup, 1);
	
	//aantal datapipes instellen hier enkel dp0
	setup[0] = 0x01;
	WriteToNrf(W,EN_RXADDR, setup, 1);	//data pipe 0 aanzetten
	
	//Rf-adres breedte instellen (1-5 in bytes)
	setup[0] = 0b00000011;		//0b0000 0011 = 5byte adres
	WriteToNrf(W,SETUP_AW, setup, 1);
	
	//rf kanaal instellen - frequentie 2.4 - 2.527ghz
	setup[0] = 0b01110000;		//kanaal 112, is een legaal kanaal buiten het bereik van bluethoot en wifi
	WriteToNrf(W,RF_CH, setup, 1);
	
	//RF_setup power down mode en data speed
	setup[0] = 0x07;
	WriteToNrf(W,RF_SETUP, setup, 1);
	
	//RX RF_adress setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x12;	//0x12 x 5 is het adres, het moet hetzelfde zijn op de reciever-transmitter
	}
	WriteToNrf(W,RX_ADDR_P0, setup, 5);	//we hebben datapipe0 gekozen, dus geven we deze een adres
	
	//TX RF_adr setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x12;		//adres hetzelfde op reciever en transmitter
	}
	WriteToNrf(W, TX_ADDR, setup, 5);
	
	//breedte van de paketten instellen
	setup[0] = datlen;	//3 bytes sturen per transmittie
	WriteToNrf(W, RX_PW_P0, setup, 1);
	
	//Config register setup- hier kiezen we reciever of transmitter mode
	setup[0] = 0b00111111;		//reciever mode, enkel interupt voor data ontvangen, power-up mode
	WriteToNrf(W, CONFIG, setup, 1);

	//het divice heeft 1.5ms nodig om in standby te gaan
	_delay_ms(100);
}

void nrf24l01_init_TX(void)		//funcite voor het initialiseren van de nrf in transmitter mode
{
	_delay_ms(100);
	
	uint8_t setup[5];	//een array om de writeToNrf functie te gebruiken
	
	//EN_AA = auto ack uitzetten voor alle datapipes
	setup[0] = 0x00;		//de registerwaarde zetten
	WriteToNrf(W,EN_AA, setup,1);	//data sturen
	
	//SETUP_RETR stelt het aantal pogingen in bij een mislukte transmittie
	setup[0] = 0x2f;		//0b0010 1111: elke 750us opnieuw proberen bij mislukking, 15keer opnieuw proberen
	WriteToNrf(W,SETUP_RETR, setup, 1);
	
	//aantal datapipes instellen hier enkel dp0
	setup[0] = 0x01;
	WriteToNrf(W,EN_RXADDR, setup, 1);	//data pipe 0 aanzetten
	
	//Rf-adres breedte instellen (1-5 in bytes)
	setup[0] = 0b00000011;		//0b0000 0011 = 5byte adres
	WriteToNrf(W,SETUP_AW, setup, 1);
	
	//rf kanaal instellen - frequentie 2.4 - 2.527ghz
	setup[0] = 0b01110000;		//kanaal 112 - is een legaal kanaal buiten het berijk van wifi
	WriteToNrf(W,RF_CH, setup, 1);
	
	//RF_setup power down mode en data speed
	setup[0] = 0x07;
	WriteToNrf(W,RF_SETUP, setup, 1);
	
	//RX RF_adress setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x12;	//0x12 x 5 is het adres, het moet hetzelfde zijn op de reciever-transmitter
	}
	WriteToNrf(W,RX_ADDR_P0, setup, 5);	//we hebben datapipe0 gekozen, dus geven we deze een adres
	
	//TX RF_adr setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x12;		//adres hetzelfde op reciever en transmitter
	}
	WriteToNrf(W, TX_ADDR, setup, 5);
	
	//breedte van de paketten instellen
	setup[0] = datlen;	//3 bytes sturen per transmittie
	WriteToNrf(W, RX_PW_P0, setup, 1);
	
	//Config register setup- hier kiezen we reciever of transmitter mode
	setup[0] = 0b01011110;		//transmitter mode, power-up, enkel interupt als transmittie gelukt is
	WriteToNrf(W, CONFIG, setup, 1);
	
	//het divice heeft 1.5ms nodig om in standby te gaan
	_delay_ms(100);
}