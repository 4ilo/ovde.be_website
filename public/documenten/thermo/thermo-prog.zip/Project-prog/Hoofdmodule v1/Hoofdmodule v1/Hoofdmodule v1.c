/*
 * Hoofdmodule_v1.c
 *
 * Created: 28/03/2015 14:43:04
 *  Author: Olivier
 */ 


#include <avr/io.h>
#define F_CPU 8000000
#include <util/delay.h>		//standaard includes
#include <string.h>
#include <avr/interrupt.h>

#include "i2c.h"
#include "nokia_5110.h"
#include "Rtc.h"			//eigen include files
#include "rotary.h"
#include "knoppen.h"
#include "nRF24L01.h"


char uurRtc[2];
char minRtc[2];			//2 var om het uur uit te lezen en af te printen

uint8_t temph1 = 0;		//2 var voor de huidige temp
uint8_t temph2 = 0;
uint8_t tempIn1 = 20;
uint8_t tempIn2 = 5;		//2 var voor de ingestelde temp

uint8_t uurhUur = 22;
uint8_t uurhMin = 00;
uint8_t uurlUur = 11;		//een aantal var om bij te houden wanneer het aan of uit moet
uint8_t uurlMin = 00;

uint8_t * recData = 1;			//variabele om nrf data te ontvangen
uint8_t data_relais[4] = {0x20,0x30,0,0};		//data om te sturen
uint8_t trxMode = 1;			//variabele om aan int door te geven of we zenden of ontvangen 1=rx;
uint8_t relais = 1;				//var om bij te houden of relais aan of uit moet

int main(void)
{	
	LCD_init();			//lcd initialiseren
	LCD_clear();
	
	InitSPI();
	nrf24l01_init_RX();		//init nrf
	INT0_interupt_init();
	
	init_RTC();			//rtc initialiseren
	RTC_write(0x02,0x11);
	RTC_write(0x01,0x04);
	
	RotaryInit();		//rotary initialiseren
	RotaryResetStatus();	//register leegmaken
	Timer0_Start();			//timer 0 opstarten
	
	uint8_t knop2 = 0;		//een var om bij te houden of de knop ingedrukt geweest is
	uint8_t knop3 = 0;
	uint8_t knop4 = 0;
	
	uint8_t aanUit = 1;		//een var om te kijken of de module aan of uit moet staan
	uint8_t uurOk = 0;		//een var om de uurstatus bij te houden
	//uint8_t uurtc = 1,mintc = 1;
	uint8_t batterij = 0;	//een var om de batterijstatus bij te houden
	
	SETBIT(DDRD,1);			//lcd-lichtje als uitgang zetten
	
	
    while(1)
    {
		/*In dit deel van het programma printen we al het nodige naar het lcd scherm.
		Daarvoor lezen we eerst het uur uit het RTC*/
		
		LCD_clear();
		get_uur();			//uur lezen uit rtc komt in 'uurRtc' en 'minRtc'
		
		LCD_write_string(0,0,uurRtc);
		LCD_write_string(12,0,":");			//uur naar scherm printen
		LCD_write_string(18,0,minRtc);
		
		if (aanUit == 1) LCD_write_string(66,0,"Aan");	//aan of uit printen op lcd
		else LCD_write_string(66,0,"uit");				//afhankelijk van de aan/uit-knop
		
		LCD_write_int(30,2,temph1);
		//LCD_write_int(20,2,temph1);
		LCD_write_string(42,2,",");				//de huidige temperatuur printen op het lcd
		LCD_write_int(48,2,temph2);
		
		LCD_write_int(60,5,tempIn1);
		LCD_write_string(72,5,",");				//de ingestelde temperatuur op het lcd tonen
		LCD_write_int(78,5,tempIn2);
		
		if (knop3 == 1)		//enkel als knop ingedrukt is tonen
		{
			LCD_write_int(0,4,uurhUur);
			LCD_write_string(12,4,":");				//het maximum aan-uur
			LCD_write_int(18,4,uurhMin);
		}
		
		if (knop4 == 1)		//enkel als knop ingedrukt is tonen 
		{
			LCD_write_int(0,4,uurlUur);
			LCD_write_string(12,4,":");				//het minimum aan-uur
			LCD_write_int(18,4,uurlMin);
		}
		
		if (batterij == 0) LCD_write_string(0,5,"bat");		//als batterij leeg is, melding op het scherm geven
		
		
		/*In dit deel lezen we de 4 knoppen uit uit de i/o expander
		  er worden ook functies aantoe gekend */
		
		lees_knoppen();			//knoppen lezen
		
		//hier wordt de temp ingesteld
		if (knoppen[3] == 1 || knop2 == 1)		//als knop 2 ingedrukt is, kan er gedraaid worden
		{
			if (((PINC & (1<<PINC2)) == 0) && knop2 == 1)		//als er op de rotary encoder gedrukt wordt,
			{													//stoppen met registreren
				knop2 = 0;
			}
			else
			{
				knop2 = 1;
				knop3 = 0;
				knop4 = 0;
			}
			switch (RotaryGetStatus())		//rotarystatus opvragen(wordt verwerkt met interupttimer)
			{
			case 1: tempMin(); RotaryResetStatus();		//als 1, dan wordt er naar links gedraaid, dus min
				break;
			case 2: tempPlus();RotaryResetStatus();		//als 2, dan wordt er naar rechts gedraaid, dus plus
				break;
			}
		} 
		//hier wordt het uitschakeluur ingesteld
		if (knoppen[0] == 1 || knop3 == 1)		//als knop 2 ingedrukt is, kan er gedraaid worden
		{
			if (((PINC & (1<<PINC2)) == 0) && knop3 == 1)		//als er op de rotary encoder gedrukt wordt,
			{													//stoppen met registreren
				knop3 = 0;
			}
			else
			{
				knop3 = 1;
				knop2 = 0;
				knop4 = 0;
			}
			switch (RotaryGetStatus())		//rotarystatus opvragen(wordt verwerkt met interupttimer)
			{
				case 1: uurhmin(); RotaryResetStatus();		//als 1, dan wordt er naar links gedraaid, dus min
				break;
				case 2: uurhplus();RotaryResetStatus();		//als 2, dan wordt er naar rechts gedraaid, dus plus
				break;
			}
		}
		
		//hier wordt het inschakeluur ingesteld
		if (knoppen[1] == 1 || knop4 == 1)		//als knop 2 ingedrukt is, kan er gedraaid worden
		{
			if (((PINC & (1<<PINC2)) == 0) && knop4 == 1)		//als er op de rotary encoder gedrukt wordt,
			{													//stoppen met registreren
				knop4 = 0;
			}
			else
			{
				knop4 = 1;
				knop2 = 0;
				knop3 = 0;
			}
			switch (RotaryGetStatus())		//rotarystatus opvragen(wordt verwerkt met interupttimer)
			{
				case 1: uurlmin(); RotaryResetStatus();		//als 1, dan wordt er naar links gedraaid, dus min
				break;
				case 2: uurlplus();RotaryResetStatus();		//als 2, dan wordt er naar rechts gedraaid, dus plus
				break;
			}
		}
		
		
		/*In dit deel gebruiken we de nrf module om de temperatuur te ontvangen*/
		
		nrf_reset();				//nrf ontvangstregister leegmaken
		recieve_Data();				//kijken of er data is
		
		if (recData[0] != 0)		//als data niet 0 is, mag het verwerkt worden
		{
			temph1 = recData[0];		//de eerste data is het eerste deel van de temp
			temph2 = recData[1];		//tweede deel
			batterij = recData[3];		//4de data is de status van de batterij
		}
		
		/*Hier kijken we of de aanuitschakelaar aan of uit staat*/
		
		if ((PINC & (1<<PINC3)) == 0) aanUit = 0;
		else aanUit = 1;
		
		if ((PINC & (1<<PINC2)) == 0) SETBIT(PORTD,1);
		else CLEARBIT(PORTD,1);
		
		/*Hier gaan we kiezen of het ventiel aangetrokken moet worden of niet*/
		
		if (aanUit == 1 && uurOk == 1)		//enkel als aanuit 1 is, mag het werken
		{
			if (temph1 < tempIn1)		//ingestelde temp voor de komma groter dan huidig?
			{
				relais = 1;				//zo ja, relais aan
			}
			else if (temph1 == tempIn1)	//ingestelde temp voor de komma gelijk aan huidig?
			{
				if (temph2 < tempIn2)	//achter de komma groter?
				{
					relais = 1;			//zo ja, relais aan
				}
				else
				{
					relais = 0;			//zo nee, relais uit
				}
			}
			else if(temph1 > tempIn1)		//als het warmer is dan ingesteld, niks doen
			{
				relais=0;		//relais uit
			}
		}
		else
		{
			relais = 0;
		}
		
		/*Hier gaan we kijken of het huidige uur wel tussen de juiste waardes valt*/
		
		
		if (uurtc > uurlUur && uurtc < uurhUur)
		{
			uurOk = 1;
		}
		else if (uurtc == uurlUur)
		{
			if (mintc > uurlMin) uurOk = 1;
			else uurOk = 0;
		}
		else if (uurtc == uurhUur)
		{
			if (mintc < uurhMin) uurOk = 1;
			else uurOk = 0;
		}
		else
		{
			uurOk = 0;
		}
		
		//hier gaan we de reciever omzetten in een transmitter om data te verzenden naar de relais module
		
				//data om te sturen
		if (relais == 1)
		{
			data_relais[1] = 0x30;
		} 
		else
		{
			data_relais[1] = 0x40;
		}
		
		naar_tx_mode();			//we zetten de tranciever in tx-mode op een ander adres
		
		nrf_reset();
		transmit_Data(data_relais);		//data versturen
		_delay_ms(100);
		
		naar_rx_mode();			//terug in normale mode
		
		
		
		
    }
}


ISR(TIMER0_OVF_vect)		//bij timer0 overflow een interupt
{
	RotaryCheckStatus();		//de richting van de rotary encoder lezen
}

ISR(INT0_vect)		//interuptroutine als er data ontvangen is
{
	nrf_int_disable();				//interupts uitzetten, want de data is ontvangen
	CLEARBIT(PORTB,1);		//ce laag maken -> stop met luisteren naar data
	
	if (trxMode == 1)	//kijken of we wel in rx-mode zitten, anders moeten we niks binnenhalen
	{
		recData = WriteToNrf(R,R_RX_PAYLOAD, recData ,datlen);	//data binnenhalen uit recieve register
	}
	
}

void tempMin(void)		//deze functie verminderd te ingestelde temp
{
	if (tempIn2 > 0)
	{
		tempIn2 = tempIn2-1;
	}
	else if (tempIn2 == 0)
	{
		if (tempIn1 > 15)
		{
			tempIn1 = tempIn1 - 1;
			tempIn2 = 9;
		}
		else if(tempIn1 == 15)
		{
			tempIn1 = 30;
			tempIn2 = 9;
			LCD_clear();
		}
	}
}

void uurhmin(void)		//deze functie verminderd het ingestelde uur
{
	if (uurhMin > 0)
	{
		uurhMin = uurhMin-1;
	}
	else if (uurhMin == 0)
	{
		if (uurhUur > 0)
		{
			uurhUur = uurhUur - 1;
			uurhMin = 59;
		}
		else if(uurhUur == 0)
		{
			uurhUur = 23;
			uurhMin = 59;
			LCD_clear();
		}
	}
}

void uurlmin(void)		//deze functie verminderd het ingestelde uur
{
	if (uurlMin > 0)
	{
		uurlMin = uurlMin-1;
	}
	else if (uurlMin == 0)
	{
		if (uurlUur > 0)
		{
			uurlUur = uurlUur - 1;
			uurlMin = 59;
		}
		else if(uurlUur == 0)
		{
			uurlUur = 23;
			uurlMin = 59;
			LCD_clear();
		}
	}
}


void tempPlus(void)		//deze functie verhoogt te ingestelde temp
{
	if (tempIn2 < 9)
	{
		tempIn2 ++;
	}
	else if (tempIn2 == 9)
	{
		if (tempIn1 < 30)
		{
			tempIn1 ++;
			tempIn2 =0;
		}
		else if (tempIn1 == 30)
		{
			tempIn1 = 15;
			tempIn2 = 0;
			LCD_clear();
		}
	}
	
}

void uurhplus(void)		//deze functie verhoogt te ingestelde temp
{
	if (uurhMin < 59)
	{
		uurhMin ++;
	}
	else if (uurhMin == 59)
	{
		if (uurhUur < 23)
		{
			uurhUur ++;
			uurhMin =0;
		}
		else if (uurhUur == 23)
		{
			uurhUur = 0;
			uurhMin = 0;
			LCD_clear();
		}
	}
	
}

void uurlplus(void)		//deze functie verhoogt te ingestelde temp
{
	if (uurlMin < 59)
	{
		uurlMin ++;
	}
	else if (uurlMin == 59)
	{
		if (uurlUur < 23)
		{
			uurlUur ++;
			uurlMin =0;
		}
		else if (uurlUur == 23)
		{
			uurlUur = 0;
			uurlMin = 0;
			LCD_clear();
		}
	}
	
}

void naar_tx_mode(void)
{
	/*eerst veranderen we het adres om met een andere module te comuniceren*/
	
	uint8_t setup[5];
	
	//RX RF_adress setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x14;	//0x12 x 5 is het adres, het moet hetzelfde zijn op de reciever-transmitter
	}
	WriteToNrf(W,RX_ADDR_P0, setup, 5);	//we hebben datapipe0 gekozen, dus geven we deze een adres
	
	//TX RF_adr setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x14;		//adres hetzelfde op reciever en transmitter
	}
	WriteToNrf(W, TX_ADDR, setup, 5);
	
	/*Nu zetten we het om naar tx-mode*/
	
	//Config register setup- hier kiezen we reciever of transmitter mode
	setup[0] = 0b01011110;		//transmitter mode, power-up, enkel interupt als transmittie gelukt is
	WriteToNrf(W, CONFIG, setup, 1);
	
	//het divice heeft 1.5ms nodig om in standby te gaan
	_delay_ms(100);
}

void naar_rx_mode(void)
{
	/*We veranderen het adres terug naar origineel*/
	
	uint8_t setup[5];
	
	//RX RF_adress setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x12;	//0x12 x 5 is het adres, het moet hetzelfde zijn op de reciever-transmitter
	}
	WriteToNrf(W,RX_ADDR_P0, setup, 5);	//we hebben datapipe0 gekozen, dus geven we deze een adres
	
	//TX RF_adr setup met 5 bytes
	for (int i=0; i<5; i++)
	{
		setup[i] = 0x12;		//adres hetzelfde op reciever en transmitter
	}
	WriteToNrf(W, TX_ADDR, setup, 5);
	
	/*Nu zetten we het om naar tx-mode*/
	
	//Config register setup- hier kiezen we reciever of transmitter mode
	setup[0] = 0b00111111;		//transmitter mode, power-up, enkel interupt als transmittie gelukt is
	WriteToNrf(W, CONFIG, setup, 1);
	
	//het divice heeft 1.5ms nodig om in standby te gaan
	_delay_ms(100);
}