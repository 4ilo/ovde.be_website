
/* Deze header file bevat een aantal functies voor bitbang-i2c en de benodigde functies om te temp uit 
een htu21d uit te lezen


void i2c_Init(void)
void i2c_Start(void)
void i2c_Stop(void)
unsigned char i2c_Write(uint8_t c)
uint8_t i2c_Read(unsigned char ack)
void init_HTU21D(void)
float read_temp(void)

*/


// Poorten voor de i2c
#define I2C_DDR DDRD
#define I2C_PIN PIND
#define I2C_PORT PORTD

// Pinnen die gebruikt worden voor de klok en de data
#define I2C_CLK 0	//contact, klok, geel
#define I2C_DAT 1	//relais, data, groen

#define I2C_DATA_HI()\
I2C_DDR &= ~ (1 << I2C_DAT);\
I2C_PORT |= (1 << I2C_DAT);
#define I2C_DATA_LO()\
I2C_DDR |= (1 << I2C_DAT);\
I2C_PORT &= ~ (1 << I2C_DAT);

#define I2C_CLOCK_HI()\
I2C_DDR &= ~ (1 << I2C_CLK);\
I2C_PORT |= (1 << I2C_CLK);
#define I2C_CLOCK_LO()\
I2C_DDR |= (1 << I2C_CLK);\
I2C_PORT &= ~ (1 << I2C_CLK);

void delay(uint8_t num)		//voor de delay
{
	_delay_ms(1);
}

void i2c_WriteBit(unsigned char c)		//1 bit uitstyren
{
	if (c > 0)				//data 0 of 1?
	{
		I2C_DATA_HI();
	}
	else
	{
		I2C_DATA_LO();
	}

	I2C_CLOCK_HI();		//klokpuls maken
	delay(1);

	I2C_CLOCK_LO();
	delay(1);

	if (c > 0)				//data terug laag maken
	{
		I2C_DATA_LO();
	}

	delay(1);
}

unsigned char i2c_ReadBit(void)		//1 bit binnenhalen
{
	I2C_DATA_HI();

	I2C_CLOCK_HI();			//klokpuls maken
	delay(1);

	unsigned char c = I2C_PIN;		//data lezen

	I2C_CLOCK_LO();
	delay(1);

	return (c >> I2C_DAT) & 1;		//Data returnen
}

// Initialiseren van de bitbang-i2c
//
void i2c_Init(void)
{
	I2C_PORT &= ~ ((1 << I2C_DAT) | (1 << I2C_CLK));	//poorten juistzetten

	I2C_CLOCK_HI();
	I2C_DATA_HI();		//startconditie

	delay(1);
}

// een startconditie sturen
void i2c_Start(void)
{
	// Bijde tegelijk op 1 zetten
	I2C_DDR &= ~ ((1 << I2C_DAT) | (1 << I2C_CLK));
	delay(1);

	I2C_DATA_LO();		//eerst data laagmaken, dan de clok
	delay(1);			//dat is een startconditie

	I2C_CLOCK_LO();
	delay(1);
}

// Stopconditie sturen
void i2c_Stop(void)
{
	I2C_CLOCK_HI();		//eerst clock naar omhoog, dan pas data
	delay(1);

	I2C_DATA_HI();
	delay(1);
}

// Een byte sturen naar de slave
unsigned char i2c_Write(uint8_t c)
{
	for (char i = 0; i < 8; i++)
	{
		i2c_WriteBit(c & 128);		//bit per bit versturen

		c <<= 1;
	}
	if (i2c_ReadBit() == 1)		//kijken of er een ack of een nack volgt
	{
		return 0;		//als bit is 1, was er een nack
	} 
	else
	{
		return 1;		//als bit is 0, was er een ack
	}
}


// Een byte lezen van de slave
//
uint8_t i2c_Read(unsigned char ack)
{
	uint8_t res = 0;		// een var voor het resultaat

	for (char i = 0; i < 8; i++)
	{
		res <<= 1;				//bit per bit lezen
		res |= i2c_ReadBit();
	}

	if (ack > 0)		//kijken of er een ack of een nack gestuurt moet worden
	{
		i2c_WriteBit(0);
	}
	else
	{
		i2c_WriteBit(1);
	}

	delay(1);

	return res;
}

void init_HTU21D(void)		//deze functie initialiseerd de Htu21d-temperatuursensor in 14-bit mode
{
	uint8_t gegevens;		//een van om tijdelijk iets op te slaan
	
	i2c_Start();
	i2c_Write(0x80);		//adres in write mode
	i2c_Write(0xFE);		//soft reset
	i2c_Stop();
	
	i2c_Start();
	i2c_Write(0x80);		//adres met schrijfcomando
	i2c_Write(0xe7);		//lees user-register comando
	
	i2c_Start();
	i2c_Write(0x81);		//lees mode
	gegevens = i2c_Read(0);		//ontvangen met nack
	gegevens |= 0x00000001;			//14-bitmode aanzetten
	
	i2c_Start();
	i2c_Write(0x80);		//schrijf mode
	i2c_Write(0xE6);		//schrijven in user-register
	i2c_Write(gegevens);	//register juistzetten
	
	i2c_Stop();
}

float read_temp(void)		//deze functie leest de meting uit, en berekend de temp in float vorm
{
	uint8_t getal1,getal2;
	uint16_t meting;
	float temperatuur;
	
	i2c_Start();
	i2c_Write(0x80);		//adres in write mode
	i2c_Write(0xF3);		//temperatuurmeting in non-hold mode

	i2c_Start();
	
	while (i2c_Write(0x81) == 0)		//kijken of de data al beschikbaar is, als niet blijven kijken
	{
		i2c_Start();
	}
	
	getal2 = i2c_Read(1);		//msb uitlezen
	getal1 = i2c_Read(1);		//lsb-uitlezen
	i2c_Read(0);				//check uitlezen maar niks mee doen
	i2c_Stop();
	
	getal1 = getal1 & 0b11111100;		//laagste 2 bits zijn statusbits, dus maskeren
	meting = getal1 | (getal2 << 8);	//msb en lsb samenvoegen tot 16-bit getal
	
	float deling = (float)meting / (float) 65536;		//de deling berekenen, met typecast
	
	temperatuur = -46.85 + (175.72*deling);			//de temperatuur berekenen
	
	return temperatuur;			//return temp
}