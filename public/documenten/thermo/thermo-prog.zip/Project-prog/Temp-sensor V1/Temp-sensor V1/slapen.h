/*
 * slapen.h
 *
 * Created: 22/04/2015 15:51:08
 *  Author: Olivier
 */ 


#include <avr/interrupt.h>
#include <avr/sleep.h>


/* Deze header file bevat een aantal functies om een avr is slaap mode te zetten. De slaap mode die hier geactiveerd
	word, is power-save, omdat deze gewekt kan worden met timer2. Timer 2 is ingesteld om om de 2ms een overflow te
	genereren.
	
	De te gebruiken functies zijn:	- init_sleep();
									- start_slaap();		//cpu gaat slapen en wordt wakker door t2
									- stop_slaap();
	
	Er moet ook een interuptroutine opgestart worden:
	
		ISR (TIMER2_OVF_vect)
		{
			stop_slaap();
		}
									
*/


void init_timer2(void)		// timer initialiseren om het slapen te kunnen onderbreken
{
	TCCR2A = 0x00;		//geen compare match
	TIMSK2 |= (1<<TOIE2);		//interupt bij overflow
	sei();
}

void timer2_start(void)		//start de timer op 
{
	TCNT2 = 0x00;			//timer leegmaken
	TCCR2B |= (1<<CS21);	//prescaler op 8
}

void timer2_stop(void)		//stop de timer
{
	TCCR2B =0x00;			//prescaler op oneindig, dus timer uit
}

//vanaf hier volgen de slaapfuncties

void init_sleep(void)
{
	init_timer2();		//timer 2 initialiseren
	SMCR  |= (1<<SM1) | (1<<SM0);		//power-save mode inschakelen(datasheet)
}

void start_slaap(void)		//start de slaapmode op, het stopt als timer2 een overflow geeft
{
	SMCR |= (1<<SE);		//slaap mode activeren door se-bit hoog te zetten
	timer2_start();			//timer 2 opstarten
	sleep_cpu();			//slaap instructie uitvoeren, nu gaan we slapen
}

void stop_slaap(void)		//timer 2 stoppen
{
	SMCR &= ~(1<<SE);		//slaap mode uitzetten door se-bit laag te maken
	timer2_stop();			//timer 2 wordt gestopt
}