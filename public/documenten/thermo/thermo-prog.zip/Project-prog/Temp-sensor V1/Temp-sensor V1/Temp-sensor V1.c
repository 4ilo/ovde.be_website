/*
 * nrf_transm.c
 *
 * Created: 21/03/2015 15:55:18
 *  Author: Olivier
 */ 


#include <avr/io.h>
#define F_CPU 1000000
#include <util/delay.h>
#include <avr/interrupt.h>

#include "nRF24L01.h"
#include "slapen.h"
#include "i2c_htu21d.h"

int main(void)
{
	InitSPI();
	init_sleep();
	nrf24l01_init_TX();
	INT0_interupt_init();
	
	uint8_t data[4] = {0,0,0,0};		//de var om data te verzenden via nrf
	
	uint8_t temp1,temp2;			//2 var om temp in op te slaan
	uint8_t cont;					//de controlevar
	uint8_t batterij;				//de batterijvar
	
	//temp1 = 21;		//testwaardes
	//temp2 = 7;
	batterij = 3;
	
	float temperatuur;			//de var om de gemeten temp in op te slaan
	
	i2c_Init();			//Init i2c en htu
	init_HTU21D();
	

    while(1)
    {
		
		temperatuur = read_temp();		//temperatuur meten
		
		#define KOMMA (10)
		int temp1 = (int)temperatuur;		// opsplisen van float in 2 integers
		int temp2 = ((int)(temperatuur*KOMMA)%KOMMA);
		
		
		cont = (~ temp1);
		
		data[0] = temp1;
		data[1] = temp2;		//data op juiste manier in datapaket steken
		data[2] = ~ data[0];
		if (batterij < 2)
		{
			data[3] = 0;
		} 
		else
		{
			data[3] = 1;
		}
		
        nrf_reset();
		transmit_Data(data);		//data versturen
		_delay_ms(500);
		
		for (uint16_t i=0; i<500; i++)
		{
			start_slaap();
		}
    }
}

ISR(INT0_vect)			//interupt routine als data in de lucht is
{
	nrf_int_disable();
	CLEARBIT(PORTB,1);		//ce laag maken
}

ISR (TIMER2_OVF_vect)		//interupt vector voor de slaapfunctie;
{
	stop_slaap();
}