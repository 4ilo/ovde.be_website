/*
 * ledCube.c
 *
 * Created: 12/01/2015 2:45:56
 *  Author: Olivier
 */ 


#define F_CPU 8000000			//cpu frequentie intern
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "Bitmap.h"				//de bitmaps

#define DATA PB0
#define LATCH PB1
#define CLK PB2
#define LAAG3 PB3			//uitgangen voor shift registers en transistors aan te sturen
#define LAAG4 PB4
#define LAAG2 PB5
#define LAAG1 PB6

#define MAX 96
			//max aantal tekens in de huidige bitmap


uint16_t kubus[MAX][4];
						
uint8_t laag = 0;			//Variabele om in de interupt de huidige laag bij te houden
uint8_t nummer = 0;			//Variabele om van de main aan de interupt het huidig nummer in de array door te geven (animatie)
uint16_t aantal;
uint8_t tijd;

void laaguit(uint16_t);		//declaratie van de functie om 1 laag naar buiten te sturen


ISR (TIMER0_OVF_vect)		//interuptroutine
{
	switch (laag)			//kijken welke laag we nu moeten laten zien
	{
		case 0: laaguit(kubus[nummer][0]); PORTB &= ~(1<<LAAG1); break;		//voor de juiste laag, het juiste getal uit de array halen,
		case 1: laaguit(kubus[nummer][1]); PORTB &= ~(1<<LAAG2); break;		//en ook de juiste laag activeren
		case 2: laaguit(kubus[nummer][2]); PORTB &= ~(1<<LAAG3); break;
		case 3: laaguit(kubus[nummer][3]); PORTB &= ~(1<<LAAG4); break;
	}
	
	laag++;				//de volgende keer in de volgende laag starten
	
	if(laag == 4)		//als alle lagen voltooid zijn, terug laag 0
	{
		laag=0;
	}
}

int main(void)
{
	
	PORTB = 0x00;				//alles op 0, is ruststand
	DDRB = 0xff;				//PoortB als uitgang
	
	DDRD = 0x00;				//poortD als input
	
	PORTB |= (1<<LAAG3) | (1<<LAAG2) | (1<<LAAG1) | (1<<LAAG4);		//alle lagen uit
	
	TIMSK0 |= (1<<TOIE0);		//interupt bij overflow
	sei();						//interupts aan
	
	TCCR0B |= (1<<CS01) |(1<<CS00);	//prescaler: 1/256, interupt om de 8ms
	
	uint8_t dipsw = PIND & 0b00000011;	//dipswitches uitlezen en enkel onderste overhouden
	_delay_ms(100);
	dipsw = PIND & 0b00000011;	//dipswitches uitlezen en enkel onderste overhouden
	_delay_ms(100);
	dipsw = PIND & 0b00000011;	//dipswitches uitlezen en enkel onderste overhouden
	_delay_ms(100);
	
	
	switch(dipsw)
	{
		case 0: kopie(1,14); aantal = 14; tijd = 250; break;
		case 1: kopie(2,16); aantal = 16; tijd = 750;  break;
		case 2: kopie(3,95); aantal = 95; tijd = 75; break;
		case 3: kopie(4,24); aantal = 24; tijd = 50; break;
	}
	
	
    while(1)					//in deze lus wordt de actieve bitmap voordurend herhaald
    {
		nummer++;			//naar de volgende lijn in de bitmap
		
		if(nummer == aantal) nummer=0;	//als alle lijnen voltooid zijn, terug naar lijn 0
		
		delay_ms(tijd);				//tijd tussen wisselen van beelden
		
    }
}

void laaguit(uint16_t data)
{
	uint16_t kopie;					//een variabele om tijdelijk in op te slaan
	
	for(uint8_t i=0; i<16; i++)		//een teller om alle 16bits uit het getal af te kunnen drukken
	{
		kopie = data;							//getal uit array kopieren
		kopie = kopie << i;						//het getal doorschuiven, elke keer 1ntje meer doorschuiven
		kopie = kopie & 0b1000000000000000;		//enkel de bovenste bit overhouden, de rest weg
		
		if(kopie == 0b1000000000000000)				//nakijken of bit hoog of laag is en dan de datalijn hoog of laag maken
		{
			PORTB |= (1<<DATA);
		}
		else
		{
			PORTB &= ~(1<<DATA);
		}
		
		PORTB |= (1<<CLK);			//puls generenen
		PORTB &= ~(1<<CLK);
	}
	
	PORTB |= (1<<LATCH);			//puls op latch generenen, dit is in 1 keer 16 bits samen naar buiten uit shift-register
	PORTB &= ~(1<<LATCH);
	
	PORTB |= (1<<LAAG3) | (1<<LAAG2) | (1<<LAAG1) | (1<<LAAG4);		//alle lagen terug uitzetten
}

void delay_ms(uint16_t t)
{
	for(uint16_t i = 0; i < t; i++)
	{
		_delay_ms(1);
	}
}


}
