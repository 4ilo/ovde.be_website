
//het eerste deel is voor de datepicker met jquery

$("document").ready(function()
		{
			$("#gebdat").datepicker(
				{
					dateFormat: "dd-mm-yy" ,
					dayNamesMin: [ "Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za" ] ,
					monthNames: [ "Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December" ] ,
					firstDay: 1
				});
		});

//hier is de functie om een cookie te maken

function setCookie(cnaam, cwaarde, dagen) 
		{
    		var d = new Date();
    		d.setTime(d.getTime() + (dagen*24*60*60*1000));
    		var verval = "expires="+d.toUTCString();
    		document.cookie = cnaam + "=" + cwaarde + "; " + verval;
		}

//vanaf hier volgt de controle voor het formulier

		var naam,email,vraag;

		function controleer () 		//de functie controleer kijkt of alles juist ingevuld is en geeft de errors
		{
			naam = document.getElementById("naam");
			email = document.getElementById("email");
			vraag = document.getElementById("vraag");

			//voor het naam-vak

			if (naam.value == "") 
			{
				document.getElementById("errorN").style.display = "inline";
			}
			else
			{
				document.getElementById("errorN").style.display = "none";
				setCookie("naam",naam.value,7);
			}

			//voor het email-vak

			if (email.value == "") 
			{
				document.getElementById("errorE").style.display = "inline";
			}
			else
			{
				if ((email.value.indexOf("@") == -1) || (email.value.indexOf(".") == -1) || (email.value.length < 4)) 
				{
					document.getElementById("errorE").style.display = "inline";
				}
				else
				{
					document.getElementById("errorE").style.display = "none";
				}	
			}

			//voor het vraag-vak

			if (vraag.value == "") 
			{
				document.getElementById("errorV").style.display = "inline";
			}
			else
			{
				document.getElementById("errorV").style.display = "none";
			}

		}

		function check () 		//de functie check controleer bij elke verandering of alles juist is ingevuld, en zet of gemailt mag worden of niet
		{
			naam = document.getElementById("naam");
			email = document.getElementById("email");
			vraag = document.getElementById("vraag");

			if ((naam.value != "") && ((email.value.indexOf("@") != -1) && (email.value.indexOf(".") != -1) && (email.value.length > 4)) && (vraag.value != "")) 		//als alles juist is, mag er gemailt worden
			{
				document.getElementById("knop").type = "submit";
			}
			else
			{
				document.getElementById("knop").type = "button";
			}
		}

		function leeg ()		//deze functie maakt alle velden leeg, en controleert terug of er verzonden mag worden.
		{
			naam = document.getElementById("naam");
			email = document.getElementById("email");
			vraag = document.getElementById("vraag");
			gebdat = document.getElementById("gebdat");

			naam.value = "";
			email.value = "";
			gebdat.value = "";
			vraag.value = "";

			check();

		}