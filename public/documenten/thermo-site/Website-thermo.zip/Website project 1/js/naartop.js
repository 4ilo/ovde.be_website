	/* Deze zelfgeschreven jquery functie zorgt ervoor dat er gekeken wordt hoeveel pixels er gescrolt is. Dit wordt opgeslagen.
	Vanaf er 180 px gescrolt is, valt de header van de pagina en mag de "totop" tevoorschijn komen.
	Als er op totop geklikt wordt, wordt er een animate functie opgeroepen die naar de top scrolt */

		$(document).ready(function(){
			$(window).scroll(function(){
				var gescrolt = $(window).scrollTop();;
				if (gescrolt > 180) 
				{
					$("#totop").show(300);		//na 300px is de header weg
				}
				else
				{
					$("#totop").hide(300);
				}
			});
			$("#topimg").click(function() {
  				$("html, body").animate({ scrollTop: 0 }, "slow");
			});
		});