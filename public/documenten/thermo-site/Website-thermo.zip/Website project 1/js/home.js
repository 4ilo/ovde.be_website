
	/*Deze jquery functie is om de dialog box te bedienen */
		$(document).ready(function(){

			var cookieok = getCookie("isok");

			if (cookieok == "") 
			{
				$("#dialog").dialog({
					dialogClass: "no-close",
					resizable: false,
					height: 250,
					width: 400,
					buttons: [
					{
						text: "Accepteer",
						click: function() {
							$( this ).dialog( "close" );
							isok();		//cookie aanmaken
						}
					},
					]
					});

			}	
		});

		function isok () 			//deze functie maakt een cookie als er geaccepteerd wordt
		{
			setCookie("isok","ok",7);
		}

		function setCookie(cnaam, cwaarde, dagen) 
		{
    		var d = new Date();
    		d.setTime(d.getTime() + (dagen*24*60*60*1000));
    		var verval = "expires="+d.toUTCString();
    		document.cookie = cnaam + "=" + cwaarde + "; " + verval;
		}

		function getCookie(cnaam) 
		{
    		var naam = cnaam + "=";
    		var ca = document.cookie.split(';');
    		for(var i=0; i<ca.length; i++) 
    		{
        		var c = ca[i];
        		while (c.charAt(0)==' ') c = c.substring(1);
        		if (c.indexOf(naam) == 0) return c.substring(naam.length,c.length);
    		}
    		return "";
		}

		function controleer () 
		{
			toontijd();
			var usernaam = getCookie("naam");
			if (usernaam != "") 
			{
				document.getElementById("welkom").innerHTML = "Welkom " + usernaam + ".";
			}
		}

/* Vanaf hier komt de timer die de datum en tijd toont */
		var Teller = 0;
		function toontijd () 
		{
			var nu = new Date();
			var maand = nu.getMonth();

			switch(maand)
			{
				case(0): maand = "Jan"; break;
				case(1): maand = "Feb"; break;
				case(2): maand = "Maa"; break;
				case(3): maand = "Apr"; break;
				case(4): maand = "mei"; break;
				case(5): maand = "Jun"; break;
				case(6): maand = "Jul"; break;
				case(7): maand = "Aug"; break;
				case(8): maand = "Sep"; break;
				case(9): maand = "Okt"; break;
				case(10): maand = "Nov"; break;
				case(11): maand = "Dec"; break;
			}


			var datum = nu.getDate();

			var dag = nu.getDay();


			switch(dag)
			{
				case(0): dag = "Zon"; break;
				case(1): dag = "Maa"; break;
				case(2): dag = "Di"; break;
				case(3): dag = "Woe"; break;
				case(4): dag = "Don"; break;
				case(5): dag = "Vrij"; break;
				case(6): dag = "Zat"; break;
			}

			var uren = nu.getHours();
			if (uren <=9)
				uren = "0"+uren;
			var minuten = nu.getMinutes();
			if (minuten <=9)
				minuten = "0"+minuten;
			var seconden = nu.getSeconds();
			if (seconden <=9)
				seconden = "0"+seconden;
			var tijdWaarde = "" + dag;
				tijdWaarde += " " + datum;
				tijdWaarde += " " + maand;
				tijdWaarde += " " + uren;
				tijdWaarde += ":"+minuten;
				tijdWaarde += ":"+seconden;
			document.getElementById('klokbalk').innerHTML=tijdWaarde;
			teller = setTimeout("toontijd()",1000);
		}