
/*Deze functie zorgt voor de fadende border rond de foto's en werkt met jquery-color*/

$(document).ready(function(){

	$("img").mouseover(function(){
		$(this).animate({
            borderColor: "#50af72"
        }, 'slow');
	});

	$("img").mouseout(function(){
		$(this).animate({
            borderColor: "transparent"
        }, 'slow');
	});
});