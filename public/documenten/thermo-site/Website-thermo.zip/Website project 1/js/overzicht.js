
//de functies om de info-foto's te veranderen

		function temps()
		{
			document.getElementById("foto").src = "images/overzicht/info2.png";
		}
		function therm()
		{
			document.getElementById("foto").src = "images/overzicht/info3.png";
		}
		function ventiel()
		{
			document.getElementById("foto").src = "images/overzicht/info4.png";
		}
		function geen()
		{
			document.getElementById("foto").src = "images/overzicht/info.png";
		}

// vanaf hier staat de gecombineerde javascript en jquery slideshow

var timer;
var teller = 2;
var foto;

var fotos = ["foto1.png","foto2.png","foto3.png","foto4.png"];

function init_slide () 
{
	 timer = setInterval(verander,6000);
	 $("#slideshow").css("background-image","url(images/slideshow/foto1.png)");
}

function verander () 
		{
			$("#slideshow").fadeOut("slow" , function()
    			{

    				$("#slideshow").css("background-image","url(images/slideshow/"+ fotos[teller] + ")");

    				if (teller == (fotos.length)-1) 
    				{
    					teller = 0;
    				}
    				else
    				{
    					teller ++;
    				}
    				
    				$("#slideshow").fadeIn("slow");
    			});
		}